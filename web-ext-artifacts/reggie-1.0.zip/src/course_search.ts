// import * as st from "./lib/storage.js"
// I'll just have to copy any functions I want.

console.log("Course_search running!");

// let code_queue = st.getSearchQueue();
// let code_entry = document.getElementById("pg0_V_tabSearch_txtCourseRestrictor");

function searchCourse(code: string) {
  console.log("Searching code!");
  let code_entry = document.getElementById(
    "pg0_V_tabSearch_txtCourseRestrictor",
  );
  console.log("Code entry: ", code_entry);
  (code_entry as HTMLTextAreaElement).value = code;
  document.getElementById("pg0_V_tabSearch_btnSearch").click();
}

console.log("ABOUT TO SEARCH");
document.addEventListener("DOMContentLoaded", () => {
  searchCourse("CSE310");
});

let section_list = [];
const observer = new MutationObserver((mutationsList, observer) => {
  for (const mutation of mutationsList) {
    if (mutation.type === "childList") {
      for (const node of mutation.addedNodes) {
        if (
          node.nodeType === Node.ELEMENT_NODE &&
          (node as Element).tagName === "tbody"
        ) {
          console.log("New tbody element added:", node);
          section_list.push(node);
        }
      }
    }
  }
});

console.log("Observing!");
observer.observe(document.body, { childList: true, subtree: true });

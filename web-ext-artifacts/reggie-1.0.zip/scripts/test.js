console.log("Reggie extension is running on this page.");

This is a manifest V3 extension for Firefox and Chrome designed to help BYU-I students register for and plan their classes for the semester.

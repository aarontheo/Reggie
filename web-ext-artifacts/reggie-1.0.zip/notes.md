Reach out to iplan@byui.edu for info about APIs for Course Search (and possibly Grad Planner)

Line ~1047 of Public_course_search.jnz contains the submit button?

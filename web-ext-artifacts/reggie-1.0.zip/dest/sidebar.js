import * as st from "./lib/storage.js";
import * as cs from "./lib/course_stuff.js";
// console.log("Sidebar.js is running");
// store("test_number", 42);
// console.log(retrieve("test_number"));
const error_elem = document.getElementById("error-message");
const inputField = document.getElementById("course-code");
function showError(err) {
    error_elem.innerText = err;
    error_elem.hidden = false;
}
function resetError() {
    error_elem.hidden = true;
}
function getCourseInput() {
    let code = inputField.value;
    return code.replace(" ", "").toUpperCase();
}
function clearCourseInput() {
    inputField.value = "";
}
async function addCourseEntry() {
    let code = getCourseInput();
    // TODO: Notify user if course code is not valid
    if (!cs.isCourseCode(code)) {
        showError(`'${code}' is not a valid course code. Codes are in the format: "ABC 123" or "DEF 456a".`);
        return;
    }
    await st.addCourse(code);
}
async function refreshCodeList() {
    let list_elem = document.getElementById("course-list");
    let course_codes = (await st.getCourses());
    list_elem.innerHTML = "";
    course_codes.forEach((code) => {
        let li = document.createElement("li");
        li.style.listStyleType = "none"; // Remove the bullet point
        let removeButton = document.createElement("button");
        removeButton.textContent = "X";
        removeButton.addEventListener("click", async () => {
            await st.removeCourse(code);
            refreshCodeList();
        });
        li.appendChild(removeButton);
        li.appendChild(document.createTextNode(code));
        list_elem.appendChild(li);
    });
}
async function main() {
    refreshCodeList();
    // Listeners needed:
    // - Button to add a course entry from the textbox
    document.getElementById("add-course").addEventListener("click", async () => {
        resetError();
        await addCourseEntry();
        refreshCodeList(); //Note: removing this breaks the functionality. It's async JS.
    });
    // This clicks the add course button when enter is pressed.
    document
        .getElementById("course-code")
        .addEventListener("keypress", async (event) => {
        if (event.key === "Enter") {
            document.getElementById("add-course").click();
        }
    });
    // The list should always accurately reflect the contents of the Set.
    // Therefore, we will add the refresh function to the storage event listener.
    browser.storage.local.onChanged.addListener(refreshCodeList);
    // Functionality needed:
    // - Function to refresh course code display list in sidebar
}
main();

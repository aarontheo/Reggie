
// export function sendMessage(recipient:string, payload:any) {
//   browser.runtime.sendMessage()
// }
